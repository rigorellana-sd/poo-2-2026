<?php
class Procesos{
    // GDU = Get Data User
    public function GDU($user,$tabla,$campo){
        $row = [];
        $modelo = new Conexion();
        $conexion = $modelo->getConexion();
        $arg = ":".$campo; // :usuario O :email
        $query = "SELECT * FROM $tabla WHERE $campo = $arg OR email = $arg";
        $stmt = $conexion->prepare($query);// Statement
        $stmt->bindParam($arg,$user);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $modelo->closeConexion();
        return $row;
    }
    // sidu = SELECT INSERT DELETE UPDATE
    public function sidu($query,$accion){
        $row = [];
        $modelo = new Conexion();
        $conexion = $modelo->getConexion();
        $stmt = null;
        try{
            $stmt = $conexion->prepare($query);
            if(!$stmt){
                return 0;
            }

            if($accion == "S" || $accion == "s"){
                $stmt->execute();
                while($result = $stmt->fetch(PDO::FETCH_ASSOC)){
                    $row[] = $result;
                }
                return $row;
            }else{
                $stmt->execute();
                return 1;
            }
        } catch (PDOException $e){
            return 0;
        } finally{
            $stmt = null;
            $modelo->closeConexion();
        }
    }
}